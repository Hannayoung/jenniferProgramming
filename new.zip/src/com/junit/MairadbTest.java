package com.junit;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MairadbTest {
	
	/*
	public static void main(String[] args)
	{
		try {
			
		}
	}
	*/
	
	public Connection mariadb() {
		
		Connection conn = null;
		try{
			//DataSource dataSource;
			//Context context = new InitialContext();
			//dataSource = (DataSource)context.lookup("jdbc/dataSourceTest");
			//conn = dataSource.getConnection();
			InitialContext initContext = new InitialContext();
		    Context envContext = (Context)initContext.lookup("java:/comp/env");
		    DataSource dataSource = (DataSource)envContext.lookup("jdbc/mariadb");    //context���� ������ ��Ī
		    conn = dataSource.getConnection();

		}catch(Exception se1){
			se1.printStackTrace();
		}
		System.out.println("\n\n- MySQL Connection Close");
		return conn;

		}
	
}
