package com.junit;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.junit.Test;

public class MairaTest {
	
	Connection conn = null;

	@Test
	public void mariadb() {
		
		
		try{
			DataSource dataSource;
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/xview");
			conn = dataSource.getConnection();
			//InitialContext initContext = new InitialContext();
		    //Context envContext = (Context)initContext.lookup("java:/comp/env");
		   // DataSource dataSource = (DataSource)envContext.lookup("jdbc/xview");    //context���� ������ ��Ī
		    //conn = dataSource.getConnection();
		    System.out.println("\n\n- MySQL Connection able");
		}catch(Exception se1){
			se1.printStackTrace();
			System.out.println("\n\n- MySQL Connection disable");

		}
		System.out.println("\n\n- MySQL Connection Close");
		
		}

}
