package com.thenew;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Iterator;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.unipoint.checkmate.xviewadapter.MariaSQLConn;
import com.unipoint.checkmate.xviewadapter.XviewDataBean;

public class Map {
	
	private volatile static Map singleton;
	
	
	Multimap<String,XviewDataBean> map;
	String logs;
	int size; 
	XviewDataBean theXviewDataBean;
	static long beforeTime = 0L;
	long afterTime = 0L;
	
	/*
	public Map()
	{
		
	}
	*/
	public Map(XviewDataBean theXviewDataBean) throws InterruptedException
	{
		this.theXviewDataBean = theXviewDataBean;
	}
	
	public static Map getInstance(XviewDataBean theXviewDataBean) throws InterruptedException
	{
		if(singleton == null)
		{
			synchronized(Map.class) {
				if(singleton == null)
				{
					System.out.println("new singleton!");
					System.out.println("insta : " + theXviewDataBean);
					singleton = new Map(theXviewDataBean);
					singleton.print();
					
				}
				
			}
		}
		else {
		System.out.println("old singleton!");
		System.out.println("insta : " + theXviewDataBean);
		}
		singleton.print();
		return singleton;
	}
	
	public void print() throws InterruptedException
	{
		
		if(beforeTime == 0 )
			beforeTime = System.currentTimeMillis();
		
		Thread.sleep(3000);
		
		afterTime = System.currentTimeMillis();
		
		long elapseTime = afterTime - beforeTime;
		
		System.out.println(elapseTime);
		
		map= ArrayListMultimap.create();
		map.put(theXviewDataBean.getTxid().toString(), theXviewDataBean);
		size = map.size();
		
		Iterator<XviewDataBean> iter = map.values().iterator();
		
		while(iter.hasNext())
		{
			theXviewDataBean = iter.next();
			System.out.println("theXviewDataBean:" + theXviewDataBean );
		}
				 
				
		if(elapseTime > 30000) {

			beforeTime = afterTime;
			
			// DB Insert
			MariaSQLConn maria = new MariaSQLConn();
			Connection conn=maria.mariadb();
			PreparedStatement pstmt = null;
			String query1 = "";
			query1 += "insert into xview_log_data_tb (txid, domainId, domainName, instanceId, instanceName, guid, clientIp, clientId, userId, networkTime, frontendTime, startTime, endTime, responseTime, cpuTime, sqlTime, fetchTime, externalcallTime, errorType, applicationName)"
							+"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			try {
				 pstmt = conn.prepareStatement(query1);
		    	 pstmt.setString(1, theXviewDataBean.getTxid());
		    	 pstmt.setString(2, theXviewDataBean.getDomainId());
		    	 pstmt.setString(3, theXviewDataBean.getDomainName());
		    	 pstmt.setString(4, theXviewDataBean.getInstanceId());
		    	 pstmt.setString(5, theXviewDataBean.getInstanceName());
		    	 pstmt.setString(6, theXviewDataBean.getGuid());
		    	 pstmt.setString(7, theXviewDataBean.getClientIp());
		    	 pstmt.setString(8, theXviewDataBean.getClientId());
		    	 pstmt.setString(9, theXviewDataBean.getUserId());
		    	 pstmt.setString(10, theXviewDataBean.getNetworkTime());
		    	 pstmt.setString(11, theXviewDataBean.getFrontendTime());
		    	 pstmt.setString(12, theXviewDataBean.getStartTime());
		    	 pstmt.setString(13, theXviewDataBean.getEndTime());
		    	 pstmt.setString(14, theXviewDataBean.getResponseTime());
		    	 pstmt.setString(15, theXviewDataBean.getCpuTime());
		    	 pstmt.setString(16, theXviewDataBean.getSqlTime());
		    	 pstmt.setString(17, theXviewDataBean.getFetchTime());
		    	 pstmt.setString(18, theXviewDataBean.getExternalcallTime());
		    	 pstmt.setString(19, theXviewDataBean.getErrorType());
		    	 pstmt.setString(20, theXviewDataBean.getApplicationName());
		    	 pstmt.execute();
		    	 conn.close();
			}catch(Exception e)
			{
				System.err.println("error!");
				System.err.println(e.getMessage());
			}
		    	 
		}
	
		 System.out.println("map:"+map);
		 System.out.println("size:"+size);
		 System.out.println("object: "+theXviewDataBean);
		
	}

}
