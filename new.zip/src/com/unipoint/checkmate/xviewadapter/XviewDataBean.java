package com.unipoint.checkmate.xviewadapter;

public class XviewDataBean {
	
	private String domainId;
	private String domainName;
	private String instanceId;
	private String instanceName;
	private String guid;
	private String clientIp;
	private String clientId;
	private String userId;
	private String networkTime;
	private String frontendTime;
	private String startTime;
	private String endTime;
	private String responseTime;
	private String cpuTime;
	private String sqlTime;
	private String fetchTime;
	private String externalcallTime;
	private String errorType;
	private String applicationName;
	private String txid;
	public String getDomainId() {
		String domainId = this.domainId;
		return domainId;
	}
	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}
	public String getDomainName() {
		String domainName = this.domainName;
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getInstanceId() {
		String instanceId = this.instanceId;
		return instanceId;
	}
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}
	public String getInstanceName() {
		String instanceName = this.instanceName;
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getGuid() {
		String guid = this.guid;
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getClientIp() {
		String clientIp = this.clientIp;
		return clientIp;
	}
	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}
	public String getClientId() {
		String clientId = this.clientId;
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getUserId() {
		String userId = this.userId;
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNetworkTime() {
		String networkTime = this.networkTime;
		return networkTime;
	}
	public void setNetworkTime(String networkTime) {
		this.networkTime = networkTime;
	}
	public String getFrontendTime() {
		String frontendTime = this.frontendTime;
		return frontendTime;
	}
	public void setFrontendTime(String frontendTime) {
		this.frontendTime = frontendTime;
	}
	public String getStartTime() {
		String startTime = this.startTime;
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		String endTime = this.endTime;
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getResponseTime() {
		String responseTime = this.responseTime;
		return responseTime;
	}
	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}
	public String getCpuTime() {
		String cpuTime = this.cpuTime;
		return cpuTime;
	}
	public void setCpuTime(String cpuTime) {
		this.cpuTime = cpuTime;
	}
	public String getSqlTime() { 
		String sqlTime = this.sqlTime;
		return sqlTime;
	}
	public void setSqlTime(String sqlTime) {
		this.sqlTime = sqlTime;
	}
	public String getFetchTime() {
		String fetchTime = this.fetchTime;
		return fetchTime;
	}
	public void setFetchTime(String fetchTime) {
		this.fetchTime = fetchTime;
	}
	public String getExternalcallTime() {
		String externalcallTime = this.externalcallTime;
		return externalcallTime;
	}
	public void setExternalcallTime(String externalcallTime) {
		this.externalcallTime = externalcallTime;
	}
	public String getErrorType() {
		String errorType = this.errorType;
		return errorType;
	}
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	public String getApplicationName() {
		String applicationName = this.applicationName;
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getTxid() {
		String txid = this.txid;
		return txid;
	}
	public void setTxid(String txid) {
		this.txid = txid;
	}
	
	
	@Override
	public String toString() {
		return "domainId=" + domainId + ", domainName=" + domainName + ", instanceId=" + instanceId
				+ ", instanceName=" + instanceName + ", guid=" + guid + ", clientIp=" + clientIp + ", clientId="
				+ clientId + ", userId=" + userId + ", networkTime=" + networkTime + ", frontendTime=" + frontendTime
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", responseTime=" + responseTime + ", cpuTime="
				+ cpuTime + ", sqlTime=" + sqlTime + ", fetchTime=" + fetchTime + ", externalcallTime="
				+ externalcallTime + ", errorType=" + errorType + ", applicationName=" + applicationName + ", txid="
				+ txid;
	}
	
	
	

}
