package com.unipoint.checkmate.xviewadapter;

import com.google.common.collect.ArrayListMultimap;
import com.jennifersoft.view.adapter.JenniferAdapter;
import com.jennifersoft.view.adapter.JenniferModel;
import com.jennifersoft.view.adapter.model.JenniferTransaction;
import com.thenew.Map;

public class XVLogImpl implements JenniferAdapter  {
	private JenniferTransaction model;
	
	public void on(JenniferModel[] message)  {
		
		
		for(int i = 0; i < message.length; i++) {
			 model = (JenniferTransaction) message[i];
			 
			 //JenniferTransaction model = (JenniferTransaction) message[i];
			 //������ Ʈ����� �����͸� model�� �޴´�.
			/*
			 com.jennifersoft.view.LogUtil.info("-- DomainI   -- :" + model.getDomainId()     );    
			 com.jennifersoft.view.LogUtil.info("-- DomainName -- :" + model.getDomainName()   );    
			 com.jennifersoft.view.LogUtil.info("-- Instance Id-- :" + model.getInstanceId()   );    
			 com.jennifersoft.view.LogUtil.info("-- Instance NM-- :" + model.getInstanceName() );    
			 com.jennifersoft.view.LogUtil.info("-- GUID       -- :" + model.getGuid()         );    
			 com.jennifersoft.view.LogUtil.info("-- Client IP  -- :" + model.getClientIp()     );    
			 com.jennifersoft.view.LogUtil.info("-- Client ID  -- :" + model.getClientId()     );    
			 com.jennifersoft.view.LogUtil.info("-- User ID    -- :" + model.getUserId()       );    
			 com.jennifersoft.view.LogUtil.info("-- NetworkTime-- :" + model.getNetworkTime()  );    
			 com.jennifersoft.view.LogUtil.info("-- Front-End T-- :" + model.getFrontendTime() );    
			 com.jennifersoft.view.LogUtil.info("-- Start Time -- :" + model.getStartTime()    );    
			 com.jennifersoft.view.LogUtil.info("-- End Time   -- :" + model.getEndTime()      );    
			 com.jennifersoft.view.LogUtil.info("--ResponseTime-- :" + model.getResponseTime() );    
			 com.jennifersoft.view.LogUtil.info("-- CPU Time   -- :" + model.getCpuTime()      );    
			 com.jennifersoft.view.LogUtil.info("-- SQL Time   -- :" + model.getSqlTime()      );    
			 com.jennifersoft.view.LogUtil.info("-- Fetch Time -- :" + model.getFetchTime()    );    
			 com.jennifersoft.view.LogUtil.info("-- External T -- :" + model.getExternalcallTime());
			 com.jennifersoft.view.LogUtil.info("-- Error Type -- :" + model.getErrorType()    );
			 com.jennifersoft.view.LogUtil.info("-- App Name   -- :" + model.getApplicationName() );
			 com.jennifersoft.view.LogUtil.info("-- TX ID      -- :" + model.getTxid()         );  
		*/
			 
			 
			 
			 /*
				
			 theXviewDataBean.setDomainId(String.valueOf(model.getDomainId()));
			 theXviewDataBean.setDomainName(String.valueOf(model.getDomainName()));
			 theXviewDataBean.setInstanceId(String.valueOf(model.getInstanceId()));
			 theXviewDataBean.setInstanceName(String.valueOf(model.getInstanceName()));
			 theXviewDataBean.setGuid(String.valueOf(model.getGuid()));
			 theXviewDataBean.setClientIp(String.valueOf(model.getClientIp()));
			 theXviewDataBean.setClientId(String.valueOf(model.getClientId()));
			 theXviewDataBean.setUserId(String.valueOf(model.getUserId()));
			 theXviewDataBean.setNetworkTime(String.valueOf(model.getNetworkTime()));
			 theXviewDataBean.setFrontendTime(String.valueOf(model.getFrontendTime()));
			 theXviewDataBean.setStartTime(String.valueOf(model.getStartTime()));
			 theXviewDataBean.setEndTime(String.valueOf(model.getEndTime()));
			 theXviewDataBean.setResponseTime(String.valueOf(model.getResponseTime()));
			 theXviewDataBean.setCpuTime(String.valueOf(model.getCpuTime()));
			 theXviewDataBean.setSqlTime(String.valueOf(model.getSqlTime()));
			 theXviewDataBean.setFetchTime(String.valueOf(model.getFetchTime()));
			 theXviewDataBean.setExternalcallTime(String.valueOf(model.getExternalcallTime()));
			 theXviewDataBean.setErrorType(String.valueOf(model.getErrorType()));
			 theXviewDataBean.setApplicationName(String.valueOf(model.getApplicationName()));
			 theXviewDataBean.setTxid(String.valueOf(model.getTxid()));
			 */
			 //request.setAttribute("theXviewDataBean", theXviewDataBean);
			 //Map map = new Map(theXviewDataBean);
			 
			 /*
			 try {
				 	System.out.print("success 1");
					System.out.print("theXviewDataBean 1 : " + theXviewDataBean);
					
					Map.getInstance(theXviewDataBean);
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
			
		}
	}
	
	public void post()
	{
		 XviewDataBean theXviewDataBean = new XviewDataBean();
		 /*
		 theXviewDataBean.setDomainId("a");
		 theXviewDataBean.setDomainName("b");
		 theXviewDataBean.setInstanceId("c");
		 theXviewDataBean.setInstanceName("d");
		 theXviewDataBean.setGuid("e");
		 theXviewDataBean.setClientIp("f");
		 theXviewDataBean.setClientId("g");
		 theXviewDataBean.setUserId("h");
		 theXviewDataBean.setNetworkTime("i");
		 theXviewDataBean.setFrontendTime("j");
		 theXviewDataBean.setStartTime("k");
		 theXviewDataBean.setEndTime("l");
		 theXviewDataBean.setResponseTime("m");
		 theXviewDataBean.setCpuTime("n");
		 theXviewDataBean.setSqlTime("o");
		 theXviewDataBean.setFetchTime("p");
		 theXviewDataBean.setExternalcallTime("q");
		 theXviewDataBean.setErrorType("r");
		 theXviewDataBean.setApplicationName("s");
		 theXviewDataBean.setTxid("v");
		 */
		 
		 theXviewDataBean.setDomainId(String.valueOf(model.getDomainId()));
		 theXviewDataBean.setDomainName(String.valueOf(model.getDomainName()));
		 theXviewDataBean.setInstanceId(String.valueOf(model.getInstanceId()));
		 theXviewDataBean.setInstanceName(String.valueOf(model.getInstanceName()));
		 theXviewDataBean.setGuid(String.valueOf(model.getGuid()));
		 theXviewDataBean.setClientIp(String.valueOf(model.getClientIp()));
		 theXviewDataBean.setClientId(String.valueOf(model.getClientId()));
		 theXviewDataBean.setUserId(String.valueOf(model.getUserId()));
		 theXviewDataBean.setNetworkTime(String.valueOf(model.getNetworkTime()));
		 theXviewDataBean.setFrontendTime(String.valueOf(model.getFrontendTime()));
		 theXviewDataBean.setStartTime(String.valueOf(model.getStartTime()));
		 theXviewDataBean.setEndTime(String.valueOf(model.getEndTime()));
		 theXviewDataBean.setResponseTime(String.valueOf(model.getResponseTime()));
		 theXviewDataBean.setCpuTime(String.valueOf(model.getCpuTime()));
		 theXviewDataBean.setSqlTime(String.valueOf(model.getSqlTime()));
		 theXviewDataBean.setFetchTime(String.valueOf(model.getFetchTime()));
		 theXviewDataBean.setExternalcallTime(String.valueOf(model.getExternalcallTime()));
		 theXviewDataBean.setErrorType(String.valueOf(model.getErrorType()));
		 theXviewDataBean.setApplicationName(String.valueOf(model.getApplicationName()));
		 theXviewDataBean.setTxid(String.valueOf(model.getTxid()));
		 System.out.println("successssssssssssssss");
			System.out.println("theXviewDataBean 1 : " + theXviewDataBean);
		 try {
			 	System.out.println("success 1");
				System.out.println("theXviewDataBean 1 : " + theXviewDataBean);
				Map.getInstance(theXviewDataBean);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
