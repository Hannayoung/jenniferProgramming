package com.unipoint.checkmate.xviewadapter;

import java.sql.Connection;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MariaSQLConn {

	public Connection mariadb() {
		
		Connection conn = null;
		try{
			DataSource dataSource;
			Context context = new InitialContext();
			System.out.println("step1");
			
			dataSource = (DataSource)context.lookup("java:/comp/env/jdbc/xview");
			System.out.println("step2");
			conn = dataSource.getConnection();
			System.out.println("step3");
			//InitialContext initContext = new InitialContext();
		    //Context envContext = (Context)initContext.lookup("java:/comp/env");
		    //DataSource dataSource = (DataSource)envContext.lookup("jdbc/xview"); 
		    //conn = dataSource.getConnection();
		    System.out.println("Mysql connectcion open");
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return conn;

		}
}