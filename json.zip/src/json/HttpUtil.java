package json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpUtil{
	
	
	public String getGuid(String url, int timeout) {
		  
	     try 
	     {
	         URL u = new URL(url);
	         HttpURLConnection c = (HttpURLConnection) u.openConnection();
	         
	         c.setRequestMethod("GET");
	         c.setRequestProperty("Content-length", "0");
	         c.setUseCaches(false);
	         c.setAllowUserInteraction(false);
	         c.setConnectTimeout(timeout);
	         c.setReadTimeout(timeout);
	         c.connect();
	         
	         int status = c.getResponseCode();
	         switch (status)  // status�� 200
	         {
	             case 200:
	             case 201:
	                 BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
	                 StringBuilder sb = new StringBuilder();
	                 String line;
	                 while ((line = br.readLine()) != null) {
	                     sb.append(line+"\n");
	                 }
	                 br.close();
	                 return sb.toString();
	         }
	     } 
	     catch (MalformedURLException e) {
	         System.out.println(e.getMessage());
	     } 
	     catch (IOException e) {
	         System.out.println(e.getMessage());
	     }
	     catch (Exception e) {
	      System.out.println(e.getMessage());      
	     }
	     
	     return null;
	}

	//�� �������� �α׸� �����;��ϱ� ������ string�� ��ȯ�ϴ� getXview �Լ��� ���� �������. 
	public String getXview(String url, int timeout) {
		  
	     try 
	     {
	         URL u = new URL(url);
	         HttpURLConnection c = (HttpURLConnection) u.openConnection();
	         
	         c.setRequestMethod("GET");
	         c.setRequestProperty("Content-type", "0");
	         c.setUseCaches(false);
	         c.setAllowUserInteraction(false);
	         c.setConnectTimeout(timeout);
	         c.setReadTimeout(timeout);
	         c.connect();
	         
	         int status = c.getResponseCode();
	         switch (status) // status�� 200
	         {
	             case 200:
	             case 201:
	                 BufferedReader vr = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
	                 StringBuilder sb2 = new StringBuilder();
	                 
	                 String line;
	                 //��� json������ �ƴ϶� .txt �����̶� �� while�� �κ��� ��� �� �� �ϴ�.
	                 while ((line = vr.readLine()) != null) {
	                     sb2.append(line+"\n");

	                 }
	                 vr.close();
	                 
	                 return sb2.toString();
	         }
	     } 
	     catch (MalformedURLException e) {
	         System.out.println(e.getMessage());
	     } 
	     catch (IOException e) {
	         System.out.println(e.getMessage());
	     }
	     catch (Exception e) {
	      System.out.println(e.getMessage());      
	     }
	     
	     return null;
	}
}
