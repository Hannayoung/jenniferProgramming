package json;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JsonParser {
	private static String gustr;
	private static String xvstr;
	private static JSONParser gparser;
	private static JSONObject gobject;
	private static JSONArray garray;
	
	private static String domainId;
	private static String txid;
	private static String startTime;
	
	

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		gustr =new HttpUtil().getGuid("http://support.jennifersoft.com:27900/api/transaction/guid?domain_id=7000&guid=-4448878174397262769&start_time=20170908153955&end_time=20170908154955&time_pattern=yyyyMMddHHmmss", 30000);
		System.out.println("gustr : " + gustr);
		
		System.out.println("gustr �̱�");
		
		gparser = new JSONParser();
		gobject = (JSONObject) gparser.parse(gustr);
		garray = (JSONArray) gobject.get("TransactionData");
		
		
		new JsonParser().guPrint();
		
		System.out.println("xvstr �̱�");
		xvstr =new HttpUtil().getXview("http://support.jennifersoft.com:27900/api/transaction/profile.txt?domain_id="+domainId+"&txid="+txid+"&time="+startTime+"&time_pattern=yyyyMMddHHmmss", 30000);
		System.out.println("xvstr : " + xvstr);
	
	}
	public void guPrint()
	{
		try {
			
			
			System.out.println("TransactionData====================");
			
			for(int i =0; i < garray.size(); i++)
			{
				JSONObject obj = (JSONObject) garray.get(i);
				System.out.println(i+"��° domainId:"+ obj.get("domainId"));
				domainId = obj.get("domainId").toString();
				System.out.println(i+"��° domainName:"+ obj.get("domainName"));
				System.out.println(i+"��° instanceId:"+ obj.get("instanceId"));
				System.out.println(i+"��° instanceName:"+ obj.get("instanceName"));
				System.out.println(i+"��° business:"+ obj.get("business"));
				System.out.println(i+"��° businessId:"+ obj.get("businessId"));
				System.out.println(i+"��° businessName:"+ obj.get("businessName"));
				System.out.println(i+"��° txid:"+ obj.get("txid"));
				txid = obj.get("txid").toString();
				System.out.println(i+"��° guid:"+ obj.get("guid"));
				System.out.println(i+"��° clientIp:"+ obj.get("clientIp"));
				System.out.println(i+"��° clientId:"+ obj.get("clientId"));
				System.out.println(i+"��° userId:"+ obj.get("userId"));
				System.out.println(i+"��° networkTime:"+ obj.get("networkTime"));
				System.out.println(i+"��° frontendTime:"+ obj.get("frontendTime"));
				System.out.println(i+"��° startTime:"+ obj.get("startTime"));
				startTime = obj.get("startTime").toString();
				System.out.println(i+"��° endTime:"+ obj.get("endTime"));
				System.out.println(i+"��° responseTime:"+ obj.get("responseTime"));
				System.out.println(i+"��° cpuTime:"+ obj.get("cpuTime"));
				System.out.println(i+"��° sqlTime:"+ obj.get("sqlTime"));
				System.out.println(i+"��° fetchTime:"+ obj.get("fetchTime"));
				System.out.println(i+"��° externalcallTime:"+ obj.get("externalcallTime"));
				System.out.println(i+"��° errorType:"+ obj.get("errorType"));
				System.out.println(i+"��° applicationName:"+ obj.get("applicationName"));
				
				
			}
			
			
		}catch(Exception e)
		{
			System.out.println("error!");
			e.printStackTrace();
		}
	
	}
	/*
	public void xvPrint()
	{
		try {
			
			
			System.out.println("xviewData====================");
			
			for(int i =0; i < xarray.size(); i++)
			{
				JSONObject obj = (JSONObject) xarray.get(i);
				System.out.println(i+"��° 0000:"+ obj.get("0000"));
				System.out.println(i+"��° 0001:"+ obj.get("0001"));
				System.out.println(i+"��° 0002:"+ obj.get("0002"));
				System.out.println(i+"��° 0003:"+ obj.get("0003"));
				System.out.println(i+"��° 0004:"+ obj.get("0004"));
				System.out.println(i+"��° 0005:"+ obj.get("0005"));
				System.out.println(i+"��° 0006:"+ obj.get("0006"));
				System.out.println(i+"��° 0007:"+ obj.get("0007"));
				System.out.println(i+"��° 0008:"+ obj.get("0008"));
			}
			
			
		}catch(Exception e)
		{
			System.out.println("error!");
			e.printStackTrace();
		}
	
	}*/
	
	
	

}


